package com.finance.platform.service;

import com.finance.platform.model.Expense;
import com.finance.platform.model.User;
import com.finance.platform.repository.ExpenseRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Expense Service - Business logic for Expense operations
 */
@Service
@RequiredArgsConstructor
@Transactional
public class ExpenseService {

    private final ExpenseRepository expenseRepository;

    public Expense createExpense(Expense expense) {
        return expenseRepository.save(expense);
    }

    public Expense updateExpense(Long id, Expense expenseDetails) {
        Expense expense = getExpenseById(id);
        expense.setCategory(expenseDetails.getCategory());
        expense.setAmount(expenseDetails.getAmount());
        expense.setDescription(expenseDetails.getDescription());
        expense.setExpenseDate(expenseDetails.getExpenseDate());
        expense.setPaymentMethod(expenseDetails.getPaymentMethod());
        expense.setMerchantName(expenseDetails.getMerchantName());
        expense.setIsRecurring(expenseDetails.getIsRecurring());
        return expenseRepository.save(expense);
    }

    public Expense getExpenseById(Long id) {
        return expenseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Expense not found with id: " + id));
    }

    public List<Expense> getExpensesByUser(User user) {
        return expenseRepository.findByUser(user);
    }

    public List<Expense> getExpensesByUserAndCategory(User user, String category) {
        return expenseRepository.findByUserAndCategory(user, category);
    }

    public List<Expense> getExpensesByDateRange(User user, LocalDate startDate, LocalDate endDate) {
        return expenseRepository.findByUserAndExpenseDateBetween(user, startDate, endDate);
    }

    public void deleteExpense(Long id) {
        expenseRepository.deleteById(id);
    }

    public Double getTotalExpenses(User user) {
        Double total = expenseRepository.getTotalExpenseByUser(user);
        return total != null ? total : 0.0;
    }

    public Double getTotalExpensesByCategory(User user, String category) {
        Double total = expenseRepository.getTotalExpenseByUserAndCategory(user, category);
        return total != null ? total : 0.0;
    }

    public Double getTotalExpensesByDateRange(User user, LocalDate startDate, LocalDate endDate) {
        Double total = expenseRepository.getTotalExpenseByUserAndDateRange(user, startDate, endDate);
        return total != null ? total : 0.0;
    }

    public Map<String, Double> getExpenseSummaryByCategory(User user) {
        List<Object[]> results = expenseRepository.getExpenseSummaryByCategory(user);
        Map<String, Double> summary = new HashMap<>();
        for (Object[] result : results) {
            summary.put((String) result[0], (Double) result[1]);
        }
        return summary;
    }

    public Map<String, Object> getExpenseDashboardData(User user) {
        Map<String, Object> dashboard = new HashMap<>();
        dashboard.put("totalExpenses", getTotalExpenses(user));
        dashboard.put("expensesByCategory", getExpenseSummaryByCategory(user));
        dashboard.put("recentExpenses", getExpensesByUser(user));
        
        LocalDate now = LocalDate.now();
        LocalDate startOfMonth = now.withDayOfMonth(1);
        dashboard.put("monthlyExpenses", getTotalExpensesByDateRange(user, startOfMonth, now));
        
        return dashboard;
    }
}
