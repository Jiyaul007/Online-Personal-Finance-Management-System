package com.finance.platform.repository;

import com.finance.platform.model.Expense;
import com.finance.platform.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Expense Repository - Database operations for Expense entity
 */
@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {
    
    List<Expense> findByUser(User user);
    
    List<Expense> findByUserAndCategory(User user, String category);
    
    List<Expense> findByUserAndExpenseDateBetween(User user, LocalDate startDate, LocalDate endDate);
    
    @Query("SELECT SUM(e.amount) FROM Expense e WHERE e.user = ?1")
    Double getTotalExpenseByUser(User user);
    
    @Query("SELECT SUM(e.amount) FROM Expense e WHERE e.user = ?1 AND e.category = ?2")
    Double getTotalExpenseByUserAndCategory(User user, String category);
    
    @Query("SELECT SUM(e.amount) FROM Expense e WHERE e.user = ?1 AND e.expenseDate BETWEEN ?2 AND ?3")
    Double getTotalExpenseByUserAndDateRange(User user, LocalDate startDate, LocalDate endDate);
    
    @Query("SELECT e.category, SUM(e.amount) FROM Expense e WHERE e.user = ?1 GROUP BY e.category")
    List<Object[]> getExpenseSummaryByCategory(User user);
}
