package com.finance.platform.repository;

import com.finance.platform.model.FinancialAdvice;
import com.finance.platform.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Financial Advice Repository - Database operations for FinancialAdvice entity
 */
@Repository
public interface FinancialAdviceRepository extends JpaRepository<FinancialAdvice, Long> {
    
    List<FinancialAdvice> findByUser(User user);
    
    List<FinancialAdvice> findByAdvisor(User advisor);
    
    List<FinancialAdvice> findByUserAndIsRead(User user, Boolean isRead);
    
    List<FinancialAdvice> findByUserAndCategory(User user, FinancialAdvice.Category category);
    
    Long countByUserAndIsRead(User user, Boolean isRead);
}
