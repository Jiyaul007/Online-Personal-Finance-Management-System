package com.finance.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

/**
 * Main Application Class for Personal Finance Management Platform
 * 
 * @author GUVI Team
 * @version 1.0
 */
@SpringBootApplication
@EnableJpaAuditing
public class FinancePlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(FinancePlatformApplication.class, args);
        System.out.println("=================================================");
        System.out.println("Personal Finance Platform Started Successfully!");
        System.out.println("API Documentation: http://localhost:8080/api");
        System.out.println("=================================================");
    }
}
