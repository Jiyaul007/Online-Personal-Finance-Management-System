package com.finance.platform.controller;

import com.finance.platform.model.Expense;
import com.finance.platform.model.Budget;
import com.finance.platform.model.User;
import com.finance.platform.service.ExpenseService;
import com.finance.platform.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * User Controller - Handles user-specific operations
 */
@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class UserController {

    private final ExpenseService expenseService;
    private final UserService userService;

    // Expense Management
    @PostMapping("/expenses")
    public ResponseEntity<?> createExpense(@Valid @RequestBody ExpenseDTO expenseDTO, 
                                          Authentication authentication) {
        try {
            User user = userService.getUserByEmail(authentication.getName());
            Expense expense = new Expense();
            expense.setUser(user);
            expense.setCategory(expenseDTO.getCategory());
            expense.setAmount(expenseDTO.getAmount());
            expense.setDescription(expenseDTO.getDescription());
            expense.setExpenseDate(expenseDTO.getExpenseDate());
            expense.setPaymentMethod(expenseDTO.getPaymentMethod());
            expense.setMerchantName(expenseDTO.getMerchantName());
            expense.setIsRecurring(expenseDTO.getIsRecurring());

            Expense savedExpense = expenseService.createExpense(expense);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(createSuccessResponse("Expense created successfully", savedExpense));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to create expense: " + e.getMessage()));
        }
    }

    @GetMapping("/expenses")
    public ResponseEntity<?> getAllExpenses(Authentication authentication) {
        try {
            User user = userService.getUserByEmail(authentication.getName());
            List<Expense> expenses = expenseService.getExpensesByUser(user);
            return ResponseEntity.ok(createSuccessResponse("Expenses retrieved successfully", expenses));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to retrieve expenses: " + e.getMessage()));
        }
    }

    @GetMapping("/expenses/{id}")
    public ResponseEntity<?> getExpenseById(@PathVariable Long id) {
        try {
            Expense expense = expenseService.getExpenseById(id);
            return ResponseEntity.ok(createSuccessResponse("Expense retrieved successfully", expense));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(createErrorResponse("Expense not found"));
        }
    }

    @PutMapping("/expenses/{id}")
    public ResponseEntity<?> updateExpense(@PathVariable Long id,
                                          @Valid @RequestBody ExpenseDTO expenseDTO) {
        try {
            Expense expenseDetails = new Expense();
            expenseDetails.setCategory(expenseDTO.getCategory());
            expenseDetails.setAmount(expenseDTO.getAmount());
            expenseDetails.setDescription(expenseDTO.getDescription());
            expenseDetails.setExpenseDate(expenseDTO.getExpenseDate());
            expenseDetails.setPaymentMethod(expenseDTO.getPaymentMethod());
            expenseDetails.setMerchantName(expenseDTO.getMerchantName());
            expenseDetails.setIsRecurring(expenseDTO.getIsRecurring());

            Expense updatedExpense = expenseService.updateExpense(id, expenseDetails);
            return ResponseEntity.ok(createSuccessResponse("Expense updated successfully", updatedExpense));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to update expense: " + e.getMessage()));
        }
    }

    @DeleteMapping("/expenses/{id}")
    public ResponseEntity<?> deleteExpense(@PathVariable Long id) {
        try {
            expenseService.deleteExpense(id);
            return ResponseEntity.ok(createSuccessResponse("Expense deleted successfully", null));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to delete expense: " + e.getMessage()));
        }
    }

    @GetMapping("/expenses/summary")
    public ResponseEntity<?> getExpenseSummary(Authentication authentication) {
        try {
            User user = userService.getUserByEmail(authentication.getName());
            Map<String, Object> summary = expenseService.getExpenseDashboardData(user);
            return ResponseEntity.ok(createSuccessResponse("Expense summary retrieved successfully", summary));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to retrieve expense summary: " + e.getMessage()));
        }
    }

    @GetMapping("/dashboard")
    public ResponseEntity<?> getDashboard(Authentication authentication) {
        try {
            User user = userService.getUserByEmail(authentication.getName());
            Map<String, Object> dashboard = new HashMap<>();
            dashboard.put("user", createUserInfo(user));
            dashboard.put("expenses", expenseService.getExpenseDashboardData(user));
            return ResponseEntity.ok(dashboard);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to load dashboard: " + e.getMessage()));
        }
    }

    private Map<String, Object> createUserInfo(User user) {
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("id", user.getId());
        userInfo.put("name", user.getName());
        userInfo.put("email", user.getEmail());
        userInfo.put("role", user.getRole());
        userInfo.put("monthlyIncome", user.getMonthlyIncome());
        return userInfo;
    }

    private Map<String, Object> createSuccessResponse(String message, Object data) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", message);
        response.put("data", data);
        return response;
    }

    private Map<String, Object> createErrorResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("error", message);
        return response;
    }
}

@lombok.Data
class ExpenseDTO {
    private String category;
    private Double amount;
    private String description;
    private LocalDate expenseDate;
    private String paymentMethod;
    private String merchantName;
    private Boolean isRecurring;
}
