package com.finance.platform.repository;

import com.finance.platform.model.Budget;
import com.finance.platform.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Budget Repository - Database operations for Budget entity
 */
@Repository
public interface BudgetRepository extends JpaRepository<Budget, Long> {
    
    List<Budget> findByUser(User user);
    
    List<Budget> findByUserAndIsActive(User user, Boolean isActive);
    
    Optional<Budget> findByUserAndCategory(User user, String category);
    
    List<Budget> findByUserAndPeriod(User user, Budget.Period period);
}
